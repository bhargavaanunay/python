var app = angular.module('dbcompare', ['ui.grid', 'ui.grid.cellNav', 'ui.grid.edit', 'ui.grid.resizeColumns', 'ui.grid.pinning']);
app.controller('configController', ['$scope', '$http', '$timeout', '$interval', function ($scope, $http, $timeout, $interval) {
    $scope.gridOptions = {};
    $scope.tabs = {selectedTabs:-1};
       $scope.send = function(url){
        
        $http({
            url: url ,
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            method: "POST",
            data: $scope.config
            }).success(function(data) {
                console.log(data);
                $scope.gridOptions.columnDefs = data.header;
                $scope.gridOptions.data = data.data;
            });
        }

        $scope.reset = function(){
            $scope.config = "";
        }
}]);
