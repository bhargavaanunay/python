from flask import Flask, request
import json
from flask.ext.cors import CORS
import argparse
import MySQLdb

app = Flask(__name__)
CORS(app)

@app.route('/', methods=['POST'])
def config():
    configs = request.form
    return json.dumps({"header":[{"name":"name"}], "data":[{"name":"anunay"}]})

def setup_parser():
    parser = argparse.ArgumentParser(description='Compare App')
    parser.add_argument('--host', dest='host', default="192.168.1.109")
    parser.add_argument('--port', dest='port', default=8080)
    parser.add_argument('--debug', dest='debug', default=True)
    parser.add_argument('--dbuser', dest='dbuser', default="root")
    parser.add_argument('--dbpass', dest='dbpass', default="root")
    parser.add_argument('--db', dest='dbname', default="furlenco")
    parser.add_argument('--dbhost', dest='dbhost', default="localhost")
    return parser

if __name__=='__main__':
    parser = setup_parser()
    args = parser.parse_args()
    app.run(host=args.host,port=args.port, debug=args.debug)
